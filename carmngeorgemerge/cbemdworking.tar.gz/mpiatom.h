/*!
 \file mpiatom.h
 **/

#ifndef MPI_ATOM_H_
#define MPI_ATOM_H_

MPI_Datatype MPI_ATOM;

#endif
